import logo from './logo.svg';
import './App.css';
import Navigation from './components/Navigation';
import Homepage from './pages/Homepage';
import Footer from './components/Footer';
import Search from './components/Search';
import About  from './pages/About'
import './style/style.css'

import {Switch, Route} from "react-router-dom"
function App() {
  return (
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
    <div className='mainWindow'>
      <Navigation/>
      <Switch>
        <Route>
          <Homepage path="/" exact/>
        </Route>
        <Route>
          <About path="/about" exact/>
        </Route>   
      </Switch>
     
      <Footer></Footer>

    </div>
  );
}

export default App;
