import React from "react";
const About = () =>{
    return(
        <div>
            <p>About Page</p>
        </div>
    )
}
export default About