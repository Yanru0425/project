import React from "react";
import Search from "../components/Search";
import Picture from "../components/Picture";
import { useState, useEffect } from "react";
const Homepage = () =>{
    const [input, setInput] = useState("")
    const [page, setPage] = useState(1)
    const authentication_code = '563492ad6f91700001000001c1265e0cd1d44a2391f4be4f10a3c6a8'
    const fetch_api = `https://api.pexels.com/v1/curated?page=1&per_page=15`;
    const search_api = `https://api.pexels.com/v1/search?query=${input}&per_page=15&page=1`;

    // const fetch_api = 'https://api.pexels.com/v1/curated?per_page=1'
    const [photos, setPhotos] = useState(null);
    const search = async (api) =>{
        const data = await fetch(api, {
            method: "GET",
            headers:{
                Accept:"application/json",
                Authorization: authentication_code
            }
        });
        let parseData = await data.json();
        setPhotos(parseData.photos)
        console.log(photos)
    }

    const loadMore = async () =>{
        let url;
        if(input === ""){
            url = `https://api.pexels.com/v1/curated?page=${page}&per_page=15`
        }else{
            url = `https://api.pexels.com/v1/search?query=${input}&per_page=15&page=${page}`
        }
        setPage(page + 1);
        const data = await fetch(url, {
            method: "GET",
            headers:{
                Accept:"application/json",
                Authorization: authentication_code
            }
        });
        let parseData = await data.json();
        setPhotos(photos.concat(parseData.photos))
        console.log(photos)

    }

    useEffect(() => {
        search(fetch_api);
    }, []);



    return <div style= {{ minHeight: "100vh" }}>
        <Search search={() => {search(search_api)}} setInput={setInput}/>
        <div className="pictures">
            {photos&&photos.map(item => {
                return <Picture data={item}/>
            })}
        </div>

        <div className="morePicture">
            <button onClick={loadMore}>Load More</button>
        </div>
    </div>
}

export default Homepage;