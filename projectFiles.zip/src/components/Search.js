import React from "react";
import { useState } from "react";
const Search = (props) =>{

    const setInput = (e) => {
        props.setInput(e.target.value);
    }
   
   
    return <div className="search">
        <input onChange={setInput} type="text"></input>
        <button onClick={props.search}>Search</button>
    </div>
}

export default Search;