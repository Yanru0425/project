import React from "react";
import {Link} from "react-router-dom";

const Navigation = () =>{
    return (<nav className="navigation">
        
        <ul>
            {/* <li className="title">
                <p>Photos</p>
            </li> */}
            <li>
                <Link to="/">Homepage</Link>
            </li>
            <li>
                <Link to="/about">About</Link>
            </li>
            <li>
                <Link to="/profile">Profile</Link>
            </li>
        </ul>
    </nav>)
}

export default Navigation;