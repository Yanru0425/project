import React from "react";

const Picture = ({data}) =>{
    return (
        <div className="imges">   
            <div className="imageContainer">
                <img src = {data.src.large} alt = ""></img>
            </div>
            <p>Download Image Here: <a target="_blank" herf={data.src.large}>Click Here</a></p>
        </div>
    )
}

export default Picture